# Project_with_Naima_Adi
First group project on landing page 
